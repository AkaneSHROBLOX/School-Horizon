const { EmbedBuilder } = require('discord.js');
const db = require('./db');

// Couleur du theme : priorite au theme du serveur, sinon theme global
function themeColor(guildId) {
  try {
    if (guildId) {
      const g = db.getGuild(guildId);
      if (g.theme) return g.theme;
    }
    return db.getGlobal().theme || '#5865F2';
  } catch {
    return '#5865F2';
  }
}

// Cree un embed pre-colore au theme
function embed(guildId) {
  return new EmbedBuilder().setColor(themeColor(guildId));
}

// Embeds utilitaires
function ok(guildId, description) {
  return embed(guildId).setDescription(`✅ ${description}`);
}
function error(description) {
  return new EmbedBuilder().setColor('#ED4245').setDescription(`❌ ${description}`);
}
function warn(description) {
  return new EmbedBuilder().setColor('#FEE75C').setDescription(`⚠️ ${description}`);
}

module.exports = { embed, ok, error, warn, themeColor };
