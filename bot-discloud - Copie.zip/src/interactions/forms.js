const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const db = require('../utils/db');
const { embed } = require('../utils/embed');
const { resolveChannel } = require('../utils/resolve');
const { groupAllows } = require('../utils/permGroups');

// Boutons de décision (candidature) posés sous la réponse
function decisionRow(userId, formId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`form_accept|${userId}|${formId}`).setLabel('Accepter').setEmoji('✅').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`form_refuse|${userId}|${formId}`).setLabel('Refuser').setEmoji('❌').setStyle(ButtonStyle.Danger),
  );
}

const MAX_QUESTIONS = 15;
const TIMEOUT = 5 * 60 * 1000; // 5 min par question

// Empêche un membre de remplir 2 formulaires en même temps
const activeSessions = new Set();

// Couleurs de bouton -> styles Discord (les seuls autorisés)
const STYLES = {
  bleu: ButtonStyle.Primary, blue: ButtonStyle.Primary, primary: ButtonStyle.Primary,
  vert: ButtonStyle.Success, green: ButtonStyle.Success, success: ButtonStyle.Success,
  rouge: ButtonStyle.Danger, red: ButtonStyle.Danger, danger: ButtonStyle.Danger,
  gris: ButtonStyle.Secondary, grey: ButtonStyle.Secondary, gray: ButtonStyle.Secondary, secondary: ButtonStyle.Secondary,
};
const styleFrom = (w) => STYLES[(w || '').toLowerCase().trim()] ?? ButtonStyle.Primary;
const newId = () => Math.random().toString(36).slice(2, 8);

// Envoie les réponses compilées dans le salon de logs (découpe si trop long)
async function sendAnswers(guild, user, form, answers, logChannel, formId) {
  if (!logChannel) return;
  const fields = form.questions.map((qu, i) => ({ name: qu.slice(0, 256), value: (answers[i] || '—').slice(0, 1024) }));
  const chunks = []; let cur = [], len = 0;
  for (const f of fields) {
    const fl = f.name.length + f.value.length;
    if (cur.length >= 8 || len + fl > 4500) { chunks.push(cur); cur = []; len = 0; }
    cur.push(f); len += fl;
  }
  if (cur.length) chunks.push(cur);
  for (let c = 0; c < chunks.length; c++) {
    const last = c === chunks.length - 1;
    const e = embed(guild.id)
      .setTitle(c === 0 ? `📋 Candidature — ${form.title}` : `📋 ${form.title} (suite ${c + 1})`)
      .addFields(chunks[c]);
    if (c === 0) e.setAuthor({ name: user.tag, iconURL: user.displayAvatarURL() }).setTimestamp();
    if (last) e.setFooter({ text: `ID: ${user.id}` });
    const payload = { embeds: [e] };
    if (last) payload.components = [decisionRow(user.id, formId)]; // boutons Accepter/Refuser
    await logChannel.send(payload).catch(() => {});
  }
}

// Entretien en MP : pose les questions une par une
async function runInterview(user, guild, form, dm, formId) {
  activeSessions.add(user.id);
  try {
    const total = form.questions.length;
    const answers = [];
    for (let i = 0; i < total; i++) {
      await dm.send({ embeds: [embed(guild.id)
        .setTitle(`Question ${i + 1}/${total}`)
        .setDescription(form.questions[i])
        .setFooter({ text: 'Écris ta réponse ci-dessous · tape "annuler" pour arrêter' })] });
      const collected = await dm.awaitMessages({ filter: m => m.author.id === user.id, max: 1, time: TIMEOUT }).catch(() => null);
      if (!collected || !collected.size) {
        await dm.send('⏱️ Temps écoulé. Formulaire annulé — reclique sur le bouton pour recommencer.').catch(() => {});
        return;
      }
      const content = (collected.first().content || '').trim();
      if (content.toLowerCase() === 'annuler') { await dm.send('❌ Formulaire annulé.').catch(() => {}); return; }
      answers.push(content.slice(0, 1024));
    }
    const logChannel = guild.channels.cache.get(form.logChannelId);
    await sendAnswers(guild, user, form, answers, logChannel, formId);
    await dm.send({ embeds: [embed(guild.id).setDescription('✅ Merci ! Tes réponses ont bien été envoyées au staff.')] }).catch(() => {});
  } catch (e) {
    console.error('Erreur formulaire (interview):', e);
  } finally {
    activeSessions.delete(user.id);
  }
}

module.exports = {
  test: (i) =>
    (i.isButton() && (i.customId === 'form_setup' || i.customId.startsWith('form_answer|') || i.customId.startsWith('form_accept|') || i.customId.startsWith('form_refuse|'))) ||
    (i.isModalSubmit() && i.customId === 'formsetup'),

  async execute(client, interaction) {
    // ---- Ouvrir la config (bouton) ----
    if (interaction.isButton() && interaction.customId === 'form_setup') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
        return interaction.reply({ content: '❌ Réservé aux administrateurs.', ephemeral: true });
      }
      const modal = new ModalBuilder().setCustomId('formsetup').setTitle('Créer un formulaire').addComponents(
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('title').setLabel('Titre du formulaire').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(200)),
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('questions').setLabel('Questions (une par ligne, max 15)').setStyle(TextInputStyle.Paragraph).setRequired(true).setPlaceholder('Ton pseudo ?\nTon âge ?\nPourquoi nous rejoindre ?')),
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('channel').setLabel('Salon des réponses (nom / ID / #salon)').setStyle(TextInputStyle.Short).setRequired(true)),
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('label').setLabel('Texte du bouton').setStyle(TextInputStyle.Short).setRequired(false).setPlaceholder('Répondre').setMaxLength(80)),
        new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('color').setLabel('Couleur bouton : bleu / vert / rouge / gris').setStyle(TextInputStyle.Short).setRequired(false).setPlaceholder('bleu')),
      );
      return interaction.showModal(modal);
    }

    // ---- Config soumise ----
    if (interaction.isModalSubmit() && interaction.customId === 'formsetup') {
      const title = interaction.fields.getTextInputValue('title');
      const questions = interaction.fields.getTextInputValue('questions').split('\n').map(q => q.trim()).filter(Boolean).slice(0, MAX_QUESTIONS);
      const logChannel = resolveChannel(interaction.guild, interaction.fields.getTextInputValue('channel'));
      const label = (interaction.fields.getTextInputValue('label') || 'Répondre').slice(0, 80);
      const colorWord = (interaction.fields.getTextInputValue('color') || 'bleu').toLowerCase().trim();
      if (!questions.length) return interaction.reply({ content: '❌ Il faut au moins une question.', ephemeral: true });
      if (!logChannel) return interaction.reply({ content: '❌ Salon des réponses introuvable.', ephemeral: true });

      const id = newId();
      db.updateGuild(interaction.guild.id, d => {
        d.forms = d.forms || {};
        d.forms[id] = { title, questions, logChannelId: logChannel.id, label, color: colorWord };
      });

      return interaction.reply({
        content: `✅ Formulaire **${title}** créé (bouton **${label}**, ${questions.length} question(s), réponses → ${logChannel}).\n`
          + `• Ajoute-le à un panneau avec **\`+formulaire panel\`** (tous) ou **\`+formulaire panel ${id}\`** (celui-ci).\n`
          + `• Crée-en un autre en recliquant sur **Créer un formulaire** pour avoir plusieurs boutons côte à côte.`,
        ephemeral: true,
      });
    }

    // ---- Répondre (entretien en MP) ----
    if (interaction.isButton() && interaction.customId.startsWith('form_answer|')) {
      const id = interaction.customId.split('|')[1];
      const form = db.getGuild(interaction.guild.id).forms?.[id];
      if (!form) return interaction.reply({ content: '❌ Ce formulaire n\'existe plus.', ephemeral: true });
      if (activeSessions.has(interaction.user.id)) {
        return interaction.reply({ content: '⚠️ Tu as déjà un formulaire en cours dans tes MP. Termine-le d\'abord (ou tape "annuler").', ephemeral: true });
      }
      // Tente d'ouvrir le MP
      let dm;
      try {
        dm = await interaction.user.createDM();
        await dm.send({ embeds: [embed(interaction.guild.id).setTitle(`📋 ${form.title}`)
          .setDescription(`Je vais te poser **${form.questions.length} question${form.questions.length > 1 ? 's' : ''}**, une par une. Réponds simplement à chaque message.\nTape **"annuler"** à tout moment pour arrêter.`)] });
      } catch {
        return interaction.reply({ content: '❌ Je ne peux pas t\'écrire en privé. Va dans **Paramètres → Confidentialité** du serveur et autorise les **messages privés**, puis reclique sur le bouton.', ephemeral: true });
      }
      await interaction.reply({ content: `📩 Je t'ai envoyé le formulaire **${form.title}** en message privé !`, ephemeral: true });
      runInterview(interaction.user, interaction.guild, form, dm, id); // détaché : ne bloque pas le handler
      return;
    }

    // ---- Décision du staff : Accepter / Refuser ----
    if (interaction.isButton() && (interaction.customId.startsWith('form_accept|') || interaction.customId.startsWith('form_refuse|'))) {
      const gconf = db.getGuild(interaction.guild.id);
      const canDecide = interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)
        || groupAllows(gconf, interaction.member, 'candidatures');
      if (!canDecide) {
        return interaction.reply({ content: '❌ Réservé au staff (permission « Gérer le serveur » ou grade autorisé).', ephemeral: true });
      }
      const accepted = interaction.customId.startsWith('form_accept|');
      const [, userId, formId] = interaction.customId.split('|');
      const form = db.getGuild(interaction.guild.id).forms?.[formId];
      const titre = form?.title || 'ta candidature';

      // Notifie le candidat en MP
      let dmOk = false;
      try {
        const candidat = await interaction.client.users.fetch(userId);
        const dmEmbed = new EmbedBuilder();
        if (accepted) {
          dmEmbed.setColor('#57F287').setTitle('✅ Candidature acceptée !')
            .setDescription(`Ta candidature pour **${titre}** sur **${interaction.guild.name}** a été **acceptée** 🎉\n\nTu seras **contacté(e) / ping très bientôt** pour un entretien. Reste disponible et garde tes MP ouverts !`);
        } else {
          const retry = Math.floor((Date.now() + 14 * 24 * 60 * 60 * 1000) / 1000);
          dmEmbed.setColor('#ED4245').setTitle('❌ Candidature refusée')
            .setDescription(`Ta candidature pour **${titre}** sur **${interaction.guild.name}** n'a malheureusement **pas été retenue** cette fois.\n\nTu pourras **retenter à partir du <t:${retry}:D>** (dans 2 semaines). Bon courage !`);
        }
        await candidat.send({ embeds: [dmEmbed] });
        dmOk = true;
      } catch { dmOk = false; }

      // Met à jour le message de candidature (couleur + décision + boutons désactivés)
      const src = interaction.message.embeds[0];
      const updated = EmbedBuilder.from(src).setColor(accepted ? '#57F287' : '#ED4245')
        .addFields({
          name: accepted ? '✅ Acceptée' : '❌ Refusée',
          value: `Par ${interaction.user} • <t:${Math.floor(Date.now() / 1000)}:R>${dmOk ? '' : '\n⚠️ Le candidat n\'a pas pu être prévenu (MP fermés).'}`,
        });
      const doneRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('form_done_a').setLabel(accepted ? `Acceptée par ${interaction.user.username}` : 'Accepter').setEmoji('✅').setStyle(ButtonStyle.Success).setDisabled(true),
        new ButtonBuilder().setCustomId('form_done_r').setLabel(!accepted ? `Refusée par ${interaction.user.username}` : 'Refuser').setEmoji('❌').setStyle(ButtonStyle.Danger).setDisabled(true),
      );
      await interaction.update({ embeds: [updated], components: [doneRow] });
    }
  },
};
