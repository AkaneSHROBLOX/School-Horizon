const { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits } = require('discord.js');
const db = require('../utils/db');
const { embed } = require('../utils/embed');

module.exports = {
  test: (i) => i.isButton() && (i.customId.startsWith('ticket_create') || ['ticket_close', 'ticket_claim'].includes(i.customId)),
  async execute(client, interaction) {
    const guild = interaction.guild;
    const conf = db.getGuild(guild.id);
    const t = conf.tickets || {};
    const types = t.types || {};

    // ----- Créer un ticket -----
    if (interaction.customId.startsWith('ticket_create')) {
      // Type sélectionné (bouton "ticket_create|<slug>") ou 1er type par défaut
      const slug = interaction.customId.includes('|') ? interaction.customId.split('|')[1] : Object.keys(types)[0];
      const type = types[slug];
      if (!type) return interaction.reply({ content: '❌ Ce type de ticket n\'existe plus.', ephemeral: true });

      // Empêche les doublons pour CE type
      const existing = guild.channels.cache.find(c => (c.topic || '').startsWith(`TICKET|${interaction.user.id}|${slug}`));
      if (existing) return interaction.reply({ content: `Tu as déjà un ticket de ce type ouvert : ${existing}`, ephemeral: true });

      await interaction.reply({ content: '🎫 Création de ton ticket...', ephemeral: true });

      // Catégorie : celle du type, sinon une catégorie "Tickets" auto
      let parent = type.categoryId ? guild.channels.cache.get(type.categoryId) : null;
      if (!parent) {
        parent = guild.channels.cache.find(c => c.type === ChannelType.GuildCategory && c.name.toLowerCase() === 'tickets')
          || await guild.channels.create({ name: 'Tickets', type: ChannelType.GuildCategory }).catch(() => null);
      }

      const overwrites = [
        { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
        { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
        { id: client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels] },
      ];
      if (type.supportRoleId) overwrites.push({ id: type.supportRoleId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] });

      const count = (t.count || 0) + 1;
      db.updateGuild(guild.id, d => { d.tickets = { ...(d.tickets || {}), count }; });

      // Nom du salon personnalisable ({count} {username} {id})
      const rawName = type.channelName || `${slug}-{count}`;
      const chName = rawName
        .replace(/{count}/gi, count)
        .replace(/{username}/gi, interaction.user.username)
        .replace(/{id}/gi, interaction.user.id)
        .toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9\-_]/g, '').slice(0, 90) || `ticket-${count}`;

      const channel = await guild.channels.create({
        name: chName,
        type: ChannelType.GuildText,
        parent: parent?.id,
        topic: `TICKET|${interaction.user.id}|${slug}|Ticket de ${interaction.user.tag}`,
        permissionOverwrites: overwrites,
      }).catch(() => null);

      if (!channel) return interaction.editReply({ content: '❌ Impossible de créer le ticket (vérifie mes permissions).' });

      // Message d'ouverture personnalisable ({user} {username} {ticket} {server})
      const rawMsg = type.openMessage || `Bienvenue {user} !\nDécris ta demande, l'équipe va te répondre.\n\nUtilise le bouton 🔒 ou \`+close\` pour fermer.`;
      const desc = rawMsg
        .replace(/{user}/gi, interaction.user.toString())
        .replace(/{username}/gi, interaction.user.username)
        .replace(/{ticket}/gi, count)
        .replace(/{server}/gi, guild.name);
      const e = embed(guild.id).setTitle(`${type.emoji || '🎫'} ${type.label} — Ticket #${count}`).setDescription(desc);
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('ticket_claim').setLabel('Prendre en charge').setEmoji('✋').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('ticket_close').setLabel('Fermer').setEmoji('🔒').setStyle(ButtonStyle.Danger),
      );
      const ping = type.supportRoleId ? `<@&${type.supportRoleId}> ` : '';
      await channel.send({ content: `${ping}${interaction.user}`, embeds: [e], components: [row] });
      return interaction.editReply({ content: `✅ Ton ticket a été créé : ${channel}` });
    }

    // ----- Prendre en charge -----
    if (interaction.customId === 'ticket_claim') {
      return interaction.reply({ embeds: [embed(guild.id).setDescription(`✋ Ticket pris en charge par ${interaction.user}.`)] });
    }

    // ----- Fermer -----
    if (interaction.customId === 'ticket_close') {
      await interaction.reply({ embeds: [embed(guild.id).setDescription(`🔒 Ticket fermé par ${interaction.user}. Suppression dans 5 secondes...`)] });
      setTimeout(() => interaction.channel.delete().catch(() => {}), 5000);
    }
  },
};
