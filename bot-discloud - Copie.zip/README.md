# 🤖 Bot de gestion v2 (style Crow Bots)

Bot Discord de gestion multi-fonctions : utilitaire, modération, contrôle du bot, logs, configuration et auto-modération.

---

## 📋 Commandes disponibles dans cette version

> Tape `+help` sur ton serveur pour le menu interactif complet.

**Utilitaire** — `serverinfo` `vocinfo` `user` `member` `role` `channel` `pic` `banner` `server pic/banner` `allbots` `alladmins` `botadmins` `boosters` `rolemembers` `snipe` `emoji` `calc` `wiki` `search wiki` `image` `ping`

**Modération** — `warn` `mute` `tempmute` `unmute` `mutelist` `kick` `ban` `tempban` `unban` `banlist` `lock/unlock` `hide/unhide` `addrole` `delrole` `derank` `sanctions` `del sanction` `clear`

**Contrôle du bot** *(owner)* — `set name/pic/banner` `theme` `playto/listen/watch/compet/stream` `remove activity` `online/idle/dnd/invisible` `say` `mainprefix` `owner/unowner` `bl/unbl/blinfo` `clear owners/bl` `leave` `mp`

**Configuration** — `prefix` `slowmode` `perms` `set perm` `del perm` `timeout` `muterole` `antispam` `antilink` `badwords` `settings`

**Logs** — `modlog` `messagelog` `voicelog` `boostlog` `rolelog` `raidlog` `autoconfiglog` `nolog`

> ℹ️ Les gros systèmes de Crow Bots (antiraid temps réel, giveaways, tickets, backups, tempvoc, twitch, multi-langue…) ne sont pas encore là. L'architecture est prête pour les ajouter catégorie par catégorie.

---

## 🚀 Étape 1 — Créer le bot sur Discord

1. Va sur https://discord.com/developers/applications → **New Application**.
2. Onglet **Bot** → **Reset Token** → copie le token (à mettre dans `.env`).
3. Toujours dans **Bot**, active les 3 **Privileged Gateway Intents** :
   - ✅ **Presence Intent**
   - ✅ **Server Members Intent**
   - ✅ **Message Content Intent**
4. Onglet **OAuth2 → URL Generator** : coche `bot`, puis la permission **Administrator**, copie le lien et ajoute le bot à ton serveur.

## 🧩 Étape 2 — Installer Node.js (sur ton PC)

Node.js n'est pas installé chez toi. Télécharge la version **LTS** ici : https://nodejs.org
Vérifie ensuite dans un terminal :

```bash
node --version   # doit afficher v18 ou plus
```

## ⚙️ Étape 3 — Configurer le bot

Dans le dossier `discord-bot` :

```bash
npm install
```

Puis copie `.env.example` en `.env` et remplis-le :

```
TOKEN=ton_token_ici
OWNER_ID=ton_id_discord     # clic droit sur ton profil > Copier l'identifiant
DEFAULT_PREFIX=+
```

> Pour avoir ton ID : Paramètres Discord → Avancés → **Mode développeur** activé, puis clic droit sur ton profil → *Copier l'identifiant*.

## ▶️ Étape 4 — Lancer le bot (test en local)

```bash
npm start
```

Si tout va bien : `✅ Connecte en tant que TonBot#1234`. Teste avec `+ping` puis `+help`.

---

## 🌐 Étape 5 — Héberger GRATUITEMENT 24h/24

Ton PC doit rester allumé si tu lances le bot en local. Pour qu'il tourne tout le temps, choisis un hébergeur :

### Option A — Bot-Hosting.net (le plus simple, gratuit) ⭐
1. Crée un compte sur https://bot-hosting.net (connexion via Discord).
2. Récupère des « coins » gratuites chaque jour → crée un serveur **Node.js**.
3. Upload le dossier (sauf `node_modules`) ou connecte ton **GitHub**.
4. Renseigne le fichier `.env`, définis la commande de démarrage `npm start`, lance.
- ➕ Gratuit, pensé pour les bots Discord. ➖ Ressources limitées.

### Option B — Oracle Cloud « Always Free » (le meilleur gratuit à long terme)
1. Crée un compte sur https://www.oracle.com/cloud/free (carte requise mais non débitée).
2. Crée une **VM Always Free** (Ubuntu).
3. Installe Node, envoie ton code (via `git clone`), et lance avec **pm2** :
   ```bash
   npm install -g pm2
   pm2 start index.js --name bot
   pm2 save && pm2 startup
   ```
- ➕ Vrai serveur 24/7, gratuit à vie, **garde tes données**. ➖ Configuration un peu technique.

### Option C — Railway / Render
- **Railway** (https://railway.app) : connecte ton GitHub, ajoute les variables d'env, déploie. Crédit gratuit mensuel limité.
- **Render** (https://render.com) : crée un **Background Worker**, commande `npm start`. ⚠️ Le plan gratuit **s'endort** → moins fiable pour un bot.

> ⚠️ **Important sur les données** : ce bot stocke sa config dans le dossier `data/` (fichiers JSON). Sur certains hébergeurs gratuits, le disque est **remis à zéro à chaque redémarrage** → tu perds les réglages. Pour garder les données de façon fiable, utilise un **VPS** (Option B) ou branche une base de données. Sur ton PC / un VPS, tout est conservé normalement.

---

## 🧱 Structure du projet

```
discord-bot/
├─ index.js              # démarrage, chargement commandes + events
├─ .env                  # ton token (à créer, ne jamais partager !)
├─ commands/             # 1 fichier = 1 catégorie (tableau de commandes)
│  ├─ general.js  utility.js  moderation.js  control.js
│  ├─ config.js   logs.js     clear.js  set.js  del.js
├─ src/
│  ├─ events/            # ready, messageCreate, logs, interactions...
│  └─ utils/             # db, embed, resolve, permissions, automod, time
└─ data/                 # config sauvegardée (auto-créée)
```

## ➕ Ajouter une commande

Ouvre le fichier de la bonne catégorie et ajoute un objet dans le tableau :

```js
{
  name: 'macommande',
  aliases: ['mc'],
  category: 'Utilitaire',
  permission: 'public', // public | mod | admin | owner
  async execute({ message, args, client, prefix }) {
    message.reply('Salut !');
  },
}
```

Elle est chargée automatiquement au prochain démarrage.
